#!/usr/bin/env python3
import argparse
from modules.recon import recon
from modules.exploit_ard import exploit_ardagent
from modules.applescript_dropper import deploy_applescript_payload
from modules.fingerprint import fingerprint
from utils.terminal_output import print_green, print_red, print_yellow, print_brew_style
from utils.install import install_dependencies

def banner():
    print(r"""
    ╔════════════════════════════════════════╗
    ║        brewbox — macOS attack CLI      ║
    ║        Offensive tools for Apple       ║
    ╚════════════════════════════════════════╝
    """)

def main():
    banner()
    parser = argparse.ArgumentParser(description="brewbox - macOS attack tool")
    subparsers = parser.add_subparsers(dest="command")

    recon_parser = subparsers.add_parser("recon", help="Run macOS recon")
    recon_parser.add_argument("--target", required=True)

    exploit_parser = subparsers.add_parser("exploit-ard", help="Attempt ARDAgent RCE")
    exploit_parser.add_argument("--target", required=True)

    payload_parser = subparsers.add_parser("applescript-dropper", help="Deploy AppleScript payload")
    payload_parser.add_argument("--target", required=True)

    fp_parser = subparsers.add_parser("fingerprint", help="Fingerprint a macOS system")
    fp_parser.add_argument("--target", required=True)

    install_parser = subparsers.add_parser("install", help="Install dependencies")

    args = parser.parse_args()

    if args.command == "recon":
        recon(args.target)
    elif args.command == "exploit-ard":
        exploit_ardagent(args.target)
    elif args.command == "applescript-dropper":
        deploy_applescript_payload(args.target)
    elif args.command == "fingerprint":
        fingerprint(args.target)
    elif args.command == "install":
        install_dependencies()
    else:
        parser.print_help()

if __name__ == "__main__":
    main()